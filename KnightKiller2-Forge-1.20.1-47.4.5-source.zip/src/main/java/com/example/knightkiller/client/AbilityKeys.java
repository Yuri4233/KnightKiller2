package com.example.knightkiller.client;

import com.example.knightkiller.KnightKiller;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.lwjgl.glfw.GLFW;
import java.util.List;

@Mod.EventBusSubscriber(modid = KnightKiller.MODID, value = Dist.CLIENT)
public class AbilityKeys {
    public static final String CATEGORY = "key.categories.knightkiller";
    public static final KeyMapping BLOOD = key("key.knightkiller.blood", GLFW.GLFW_KEY_R);
    public static final KeyMapping DASH = key("key.knightkiller.dash", GLFW.GLFW_KEY_V);
    public static final KeyMapping ICE = key("key.knightkiller.ice", GLFW.GLFW_KEY_C);
    public static final KeyMapping LIGHTNING = key("key.knightkiller.lightning", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SOUL = key("key.knightkiller.soul", GLFW.GLFW_KEY_X);
    public static final KeyMapping ULTIMATE = key("key.knightkiller.ultimate", GLFW.GLFW_KEY_B);

    private static KeyMapping key(String name, int code) {
        return new KeyMapping(name, InputConstants.Type.KEYSYM, code, CATEGORY);
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(BLOOD); event.register(DASH); event.register(ICE);
        event.register(LIGHTNING); event.register(SOUL); event.register(ULTIMATE);
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        while (BLOOD.consumeClick()) {
            if (mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get())) {
                mc.player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 80, 0));
                mc.player.heal(2.0F);
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.CRIT, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), 0, .2, 0);
            }
        }
        while (DASH.consumeClick()) {
            if (mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get())) {
                var look = mc.player.getLookAngle();
                mc.player.setDeltaMovement(look.x * 1.8, Math.max(.25, look.y * 1.2), look.z * 1.8);
                mc.player.hasImpulse = true;
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.PORTAL, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), 0, .1, 0);
            }
        }
        while (ICE.consumeClick()) {
            applyToNearby(mc, MobEffects.MOVEMENT_SLOWDOWN, 100, 2);
        }
        while (LIGHTNING.consumeClick()) {
            applyToNearby(mc, MobEffects.GLOWING, 100, 0);
            if (mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get()))
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), .4, .4, .4);
        }
        while (SOUL.consumeClick()) {
            if (mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get())) {
                mc.player.heal(4.0F);
                mc.player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 0));
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.SOUL, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), .2, .4, .2);
            }
        }
        while (ULTIMATE.consumeClick()) {
            applyToNearby(mc, MobEffects.WEAKNESS, 160, 1);
            if (mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get()))
                mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.EXPLOSION, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), 0, 0, 0);
        }
    }

    private static void applyToNearby(Minecraft mc, net.minecraft.world.effect.MobEffect effect, int duration, int amp) {
        if (!mc.player.getMainHandItem().is(KnightKiller.KNIGHT_KILLER.get())) return;
        AABB area = mc.player.getBoundingBox().inflate(5.0);
        List<LivingEntity> targets = mc.level.getEntitiesOfClass(LivingEntity.class, area,
            e -> e != mc.player && e.isAlive());
        for (LivingEntity e : targets) e.addEffect(new MobEffectInstance(effect, duration, amp));
        mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.SWEEP_ATTACK, mc.player.getX(), mc.player.getY()+1, mc.player.getZ(), 0, 0, 0);
    }
}
